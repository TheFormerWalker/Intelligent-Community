package com.example.a19753.first.domain;

/**
 * Created by 19753 on 2019/3/1.
 */


public class Message_notice {
    ID Message_notice;

    private String ID=String.valueOf(Message_notice.getID());
    private String username;
    private String friendname;
    private String type;
    private String describe;
    private boolean Ischecked;



    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFriendname() {
        return friendname;
    }

    public void setFriendname(String friendname) {
        this.friendname = friendname;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public String getID() {
        return ID;
    }

    public boolean getIschecked() {
        return Ischecked;
    }

    public void setIschecked(boolean ischecked) {
        this.Ischecked = ischecked;
    }
}
