package com.example.a19753.first.domain;

/**
 * Created by 19753 on 2019/3/3.
 */

public class Amusement_activity {
    ID Amusement_activity;

    private String Amusement_activityID=String.valueOf(Amusement_activity.getID());
    private String username;
    private String describe;
    private String address;
    private int Number_of_complaints;
    private int Number_of_praise;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public String getAmusement_activityID() {
        return Amusement_activityID;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String username) {
        this.address = address;
    }

    public int getNumber_of_complaints() {
        return Number_of_complaints;
    }

    public void setNumber_of_complaints(int Number_of_complaints) {
        this.Number_of_complaints = Number_of_complaints;
    }

    public int getNumber_of_praise() {
        return Number_of_praise;
    }

    public void setNumber_of_praise(int Number_of_praise) {
        this.Number_of_praise = Number_of_praise;
    }
}
