package com.example.a19753.first.domain;

/**
 * Created by 19753 on 2019/3/3.
 */

import com.example.a19753.first.domain.ID;

public class Follow {
    ID Follow;

    private String FollowID=String.valueOf(Follow.getID());
    private String username;
    private String username_followed;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername_followed() {
        return username_followed;
    }

    public void setUsername_followed(String describe) {
        this.username_followed = username_followed;
    }


    public String getFollowID() {
        return FollowID;
    }

}
