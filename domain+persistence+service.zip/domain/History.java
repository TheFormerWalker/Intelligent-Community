package com.example.a19753.first.domain;

/**
 * Created by 19753 on 2019/3/1.
 */

import com.example.a19753.first.domain.ID;

public class History {
    ID History;

    private String username;
    private String thing;
    private String thetime;
    private String type;
    private String HistoryID=String.valueOf(History.getID());




    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getThing() {
        return thing;
    }

    public void setThing(String thing) {
        this.thing = thing;
    }

    public String getThetime() {
        return thetime;
    }

    public void setThetime(String thetime) {
        this.thetime = thetime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getHistoryID(){return HistoryID;}


}
