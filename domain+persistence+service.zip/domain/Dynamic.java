package com.example.a19753.first.domain;

/**
 * Created by 19753 on 2019/3/3.
 */

public class Dynamic {
    ID Dynamic;

    private String DynamicID=String.valueOf(Dynamic.getID());
    private String username;
    private String describe;
    private String img;//How to restore several imgs; use the src

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getDynamicID() {
        return DynamicID;
    }
}
