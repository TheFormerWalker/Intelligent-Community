package com.example.a19753.first.domain;

/**
 * Created by 19753 on 2019/3/3.
 */

public class ID {
    private int ID=0;

    public int getID() {
        ID=ID+1;
        return ID;
    }
}
