package com.example.a19753.first.persistence;

import com.example.a19753.first.domain.Dynamic;

/**
 * Created by 19753 on 2019/3/3.
 */

public interface DynamicDAO {
    void delete_Dynamic_ByID(String ID);
    String find_DynamicIDs_By_username(String username);//return the IDs of the dynamics
    Dynamic find_Dynamic_By_ID(String ID);
}
