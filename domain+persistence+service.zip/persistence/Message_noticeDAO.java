package com.example.a19753.first.persistence;

import com.example.a19753.first.domain.Message_notice;

/**
 * Created by 19753 on 2019/3/1.
 */

public interface Message_noticeDAO {
    void insert_Message_notice(Message_notice message_notice);
    void deleteByID(String ID);
    void change_state_ByID(String ID);
}
