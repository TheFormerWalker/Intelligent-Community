package com.example.a19753.first.persistence;

import com.example.a19753.first.domain.Interest_circle;

/**
 * Created by 19753 on 2019/3/3.
 */

public interface Interest_circleDAO {
    void Set_Interest_circle_for_user(Interest_circle interest_circle);
    Interest_circle Find_Interest_circle_By_Username(String username);
}
