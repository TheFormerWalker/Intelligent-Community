package com.example.a19753.first.persistence;

import com.example.a19753.first.domain.Account;

/**
 * Created by 19753 on 2019/3/1.
 */

public interface HistoryDAO {
    void Upload_place_of_amusement(Account account, String describe);
    void Launching_amusement(Account account, String describe);
    void View_of_dynamic(Account account, String describe);
    void View_of_article(Account account, String describe);
    void attend_of_competition(Account account, String describe);
    void deleteByID(String ID);

}
