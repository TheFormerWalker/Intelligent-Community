package com.example.a19753.first.persistence;

import com.example.a19753.first.domain.Follow;

/**
 * Created by 19753 on 2019/3/3.
 */

public interface FollowDAO {
       void restore_follow(Follow follow);
       void delete_follow_by_ID(String ID);
}
