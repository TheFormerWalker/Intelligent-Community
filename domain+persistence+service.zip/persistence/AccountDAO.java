package com.example.a19753.first.persistence.impl;

import com.example.a19753.first.domain.Account;

/**
 * Created by 19753 on 2019/3/1.
 */

public interface AccountDAO {
    Account getAccountByUsername(String username);

    Account findAccountByNameAndPassWord(Account account);

    void insertAccount(Account account);

    void insertProfile(Account account);

    void insertSignon(Account account);

    void updateAccount(Account account);

    void updateProfile(Account account);

    void updateSignon(Account account);

    boolean usernameIsExist (Account account);
}
