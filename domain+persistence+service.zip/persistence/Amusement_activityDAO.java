package com.example.a19753.first.persistence;

import com.example.a19753.first.domain.Amusement_activity;

/**
 * Created by 19753 on 2019/3/3.
 */

public interface Amusement_activityDAO {
   void delete_Amusement_activity_ByID(String ID);
    String find_Amusement_activityIDs_By_username(String username);//return the IDs of the Amusement_activityDAO
    Amusement_activity find_Amusement_activityDAO_By_ID(String ID);
}
